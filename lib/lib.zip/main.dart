// lib/main.dart
import 'package:flutter/material.dart';
import 'package:sannavi/app.dart'; // 가정된 프로젝트 이름

void main() {
  runApp(const ParkMateApp());
}